package model.beans;

public class MetodoDiPagamentoBean {
private String NumeroCarta, TipoCarta, EmailCliente;
public MetodoDiPagamentoBean() {
	
}
public String getNumeroCarta() {
	return NumeroCarta;
}
public void setNumeroCarta(String numeroCarta) {
	NumeroCarta = numeroCarta;
}
public String getEmailCliente() {
	return EmailCliente;
}
public void setEmailCliente(String emailCliente) {
	EmailCliente = emailCliente;
}
public String getTipoCarta() {
	return TipoCarta;
}
public void setTipoCarta(String tipoCarta) {
	TipoCarta = tipoCarta;
}

}
