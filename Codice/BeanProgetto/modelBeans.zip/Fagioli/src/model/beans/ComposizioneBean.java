package model.beans;

public class ComposizioneBean {
private String IdProdotto, IdOrdine;
public ComposizioneBean() {
	
}
public String getIdProdotto() {
	return IdProdotto;
}
public void setIdProdotto(String idProdotto) {
	IdProdotto = idProdotto;
}
public String getIdOrdine() {
	return IdOrdine;
}
public void setIdOrdine(String idOrdine) {
	IdOrdine = idOrdine;
}

}
